﻿using Microsoft.AspNetCore.Mvc;
using MessageApi.Models;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using MessageApi.Data;
using MessageApi.Services;

namespace MessageApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MessageController : ControllerBase
    {
        private readonly ApplicationDbContext _context;  
        private readonly ILogger<MessageController> _logger;
        private readonly IMessageService _messageService;
        
        public MessageController(ApplicationDbContext context, ILogger<MessageController> logger, IMessageService messageService)
        {
            _context = context;
            _logger = logger;
            _messageService = messageService;
        }

        [HttpPost]
        public IActionResult SendMessage([FromBody] UserRequest userRequest)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            
            _context.UserRequests.Add(userRequest);
            _context.SaveChanges();  
            
            _messageService.SendMessage(userRequest.Name, userRequest.PhoneNumber);
            
            _logger.LogInformation($"Mensaje de bienvenida enviado a {userRequest.Name} al número {userRequest.PhoneNumber}");

            return Ok(new { Message = "Datos recibidos correctamente", User = userRequest });
        }

        [HttpGet]
        public IActionResult GetAllUsers()
        {
            var users = _context.UserRequests.ToList();  
            return Ok(users);
        }
    }
}

