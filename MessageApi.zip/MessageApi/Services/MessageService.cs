﻿namespace MessageApi.Services
{
    public class MessageService : IMessageService
    {
        public void SendMessage(string name, string phoneNumber)
        {            
            Console.WriteLine($"Mensaje enviado a {name} al número {phoneNumber}");
        }
    }
}
