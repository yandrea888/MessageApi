﻿namespace MessageApi.Services
{
    public interface IMessageService
    {
        void SendMessage(string name, string phoneNumber);
    }
}

