﻿using System.ComponentModel.DataAnnotations;

namespace MessageApi.Models
{
    public class UserRequest
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre es obligatorio.")]
        public string? Name { get; set; } 

        [Required(ErrorMessage = "El número de teléfono es obligatorio.")]
        [Phone(ErrorMessage = "El número de teléfono no es válido.")]
        public string? PhoneNumber { get; set; } 
    }
}

